# -*- encoding:utf-8 -*-
import allure
import pytest
from sourcefile.MethodCase import method_case, get_list
from sourcefile.Saas import saas_case, get_list
from dataready.GetExcelData import GetExcelData
import dataready.global_var as gl

class TestRun:

    # @allure.feature("乐学培优DIFF接口比对")
    # @allure.story("APP相关接口")
    # @allure.severity("critical")
    # @pytest.mark.parametrize("url,url2,header,req,method,expect,remark,relation",
    #                          GetExcelData().get_test_case("jdy_order_controller"),
    #                          ids=get_list(len(GetExcelData().get_test_case("jdy_order_controller"))))
    # def test_order_controller(self, url,url2, header, req, method, expect, remark,relation):
    #     """
    #             ********************************************************************
    #             测试类型： 新老接口比对
    #             接口说明： 登录接口比对
    #             ********************************************************************
    #     """
    #
    #     method_case(url,url2, header, req, method, expect, remark,relation)


    @allure.feature("SAAS相关接口")
    @allure.story("基础数据校验")
    @allure.severity("critical")
    @pytest.mark.parametrize("url,sql,user,header,req,method,expect,remark,relation,parameterization",
                             GetExcelData().get_saas_case("saas_controller"),
                             ids=get_list(len(GetExcelData().get_saas_case("saas_controller"))))
    def test_order_controller2(self, url, sql,user, header, req, method, expect, remark, relation,parameterization):
        """
                ********************************************************************
                测试类型： SAAS接口比对

                ********************************************************************
        """


        saas_case(url, sql, user,header, req, method, expect, remark, relation,parameterization)

if __name__ == '__main__':
        pytest.main(['-v', 'JinDouYun.py'])
