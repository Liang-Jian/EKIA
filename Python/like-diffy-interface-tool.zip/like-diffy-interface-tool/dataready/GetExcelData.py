# -*- encoding:utf-8 -*-
import os

from ruamel import yaml
from sourcefile.ReadWriteExcel import ReadWriteExcel


class GetExcelData(object):

    def __init__(self):
        self.file = open((os.path.abspath('..') + "/configure/database.yml"), "r", encoding="utf8")
        self.config = yaml.load(self.file.read(), Loader=yaml.Loader)
        self.file.close()

    def get_test_case(self, test_case_name):
        # 依据配置名称，获取用例所有case的入参
        conf = self.config[test_case_name]
        # 初始化所需数据
        path = conf["path"]
        sheet = conf["sheet"]
        start_row_no = conf["startRowNo"]
        finish_row_no = conf["finishRowNo"]
        req_url = conf["req_url"]
        req_header = conf["req_header"]
        req_params = conf["req_params"]
        req_method = conf["req_method"]
        req_expect = conf["req_expect"]
        req_remark = conf["req_remark"]
        req_relation = conf["req_relation"]
        req_url2 = conf["req_url2"]
        excel = ReadWriteExcel(os.path.abspath('..') + "/testcase/" + path)

        case_list = [("None", "None", "None", "None", "None", "None", "None", "None")]
        urls = []
        url2s = []
        headers = []
        requests = []
        methods = []
        expects = []
        remarks = []
        relations = []

        if start_row_no > finish_row_no or start_row_no < 1:
            return case_list
        for row_no in range(start_row_no, finish_row_no + 1):
            url = excel.get_cell_value(sheet, row_no, req_url)
            url2 = excel.get_cell_value(sheet, row_no, req_url2)
            header = excel.get_cell_value(sheet, row_no, req_header)
            request = excel.get_cell_value(sheet, row_no, req_params)
            method = excel.get_cell_value(sheet, row_no, req_method)
            expect = excel.get_cell_value(sheet, row_no, req_expect)
            remark = excel.get_cell_value(sheet, row_no, req_remark)
            relation = excel.get_cell_value(sheet, row_no, req_relation)

            urls.append(url)
            url2s.append(url2)
            headers.append(header)
            requests.append(request)
            methods.append(method)
            expects.append(expect)
            remarks.append(remark)
            relations.append(relation)
        case_list = list(zip(urls,url2s, headers, requests, methods, expects, remarks,relations))
        excel.close()
        return case_list
    def get_saas_case(self, test_case_name):
        # 依据配置名称，获取用例所有case的入参
        conf = self.config[test_case_name]
        # 初始化所需数据
        path = conf["path"]
        sheet = conf["sheet"]
        start_row_no = conf["startRowNo"]
        finish_row_no = conf["finishRowNo"]
        req_url = conf["req_url"]
        req_header = conf["req_header"]
        req_params = conf["req_params"]
        req_method = conf["req_method"]
        req_expect = conf["req_expect"]
        req_remark = conf["req_remark"]
        req_relation = conf["req_relation"]
        req_sql = conf["req_sql"]
        req_user = conf["req_user"]
        req_parameterization = conf["parameterization"]
        excel = ReadWriteExcel(os.path.abspath('..') + "/testcase/" + path)

        case_list = [("None", "None", "None", "None", "None", "None", "None", "None", "None", "None")]
        urls = []
        sqls = []
        users = []
        headers = []
        requests = []
        methods = []
        expects = []
        remarks = []
        relations = []
        parameterizations = []

        if start_row_no > finish_row_no or start_row_no < 1:
            return case_list
        for row_no in range(start_row_no, finish_row_no + 1):
            url = excel.get_cell_value(sheet, row_no, req_url)
            sql = excel.get_cell_value(sheet, row_no, req_sql)
            user = excel.get_cell_value(sheet, row_no, req_user)
            header = excel.get_cell_value(sheet, row_no, req_header)
            request = excel.get_cell_value(sheet, row_no, req_params)
            method = excel.get_cell_value(sheet, row_no, req_method)
            expect = excel.get_cell_value(sheet, row_no, req_expect)
            remark = excel.get_cell_value(sheet, row_no, req_remark)
            relation = excel.get_cell_value(sheet, row_no, req_relation)
            parameterization = excel.get_cell_value(sheet, row_no, req_parameterization)

            urls.append(url)
            sqls.append(sql)
            users.append(user)
            headers.append(header)
            requests.append(request)
            methods.append(method)
            expects.append(expect)
            remarks.append(remark)
            relations.append(relation)
            parameterizations.append(parameterization)
        case_list = list(zip(urls,sqls,users, headers, requests, methods, expects, remarks,relations,parameterizations))
        excel.close()
        return case_list
