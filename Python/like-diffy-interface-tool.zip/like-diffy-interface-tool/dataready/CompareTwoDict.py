# 值相等
EQUAL = '值一样'
# 值不等
DIFF = '值不一样'
# 独有key
MORE = '比线上多'
# 缺失key
LACK = '比线上少'
class CompareTwoDict(object):
    """比较两个字典差异"""
    def __init__(self, dict1, dict2):
        self.dict1 = dict1
        self.dict2 = dict2
        self.key_list = self.keys(dict1, dict2)
        self.result = {}

    def compare(self, key):
      """比较一个key"""
     # 这里默认value不是None
      v1 = self.dict1.get(key)
      v2 = self.dict2.get(key)
     # 如果都是字典继续深入比较
      if (type(v1) == dict) and (type(v2) == dict):
          self.result[key] = CompareTwoDict(v1, v2).main()
      else:
         self.result[key] = self.diff(v1, v2)

    @staticmethod
    def diff(v1, v2):
        if (v1 is not None) and (v2 is not None):
            if v1 == v2:
               return EQUAL
            else:
                return DIFF
        elif v1 is not None:
            return MORE
        else:
            return LACK

    @staticmethod
    def keys(dict1, dict2):
        """获取所有key"""
        return list(d1.keys())+list(d2.keys())


    def main(self):
        for k in self.key_list:
            self.compare(k)
        return self.result

def compare_data(data_1, data_2):
    """
    对比两个 dict。
    :param data_1:
    :param data_2:
    :return: data_1 所独有的键值对, data_2 所独有的键值对, 相同 key 对比结果
    """
    if isinstance(data_1, dict) and isinstance(data_2, dict):
        diff_data = {}
        only_data_1_has = {}
        only_data_2_has = {}
        d2_keys = list(data_2.keys())
        for d1k in data_1.keys():
            if d1k in d2_keys:  # d1,d2都有。去往深层比对
                d2_keys.remove(d1k)

                temp_only_data_1_has, temp_only_data_2_has, temp_diff_data = compare_data(data_1.get(d1k), data_2.get(d1k))
                if temp_only_data_1_has:
                    only_data_1_has[d1k] = temp_only_data_1_has
                if temp_only_data_2_has:
                    only_data_2_has[d1k] = temp_only_data_2_has
                if temp_diff_data:
                    diff_data[d1k] = temp_diff_data
            else:
                only_data_1_has[d1k] = data_1.get(d1k)  # d1有d2没有的key
        for d2k in d2_keys:  # d2有d1没有的key
            only_data_2_has[d2k] = data_2.get(d2k)
        return only_data_1_has, only_data_2_has, diff_data
    else:
        if data_1 == data_2:
            return None, None, None
            # return None, None, "eq"
        else:
            return None, None, [data_1, data_2]


if __name__ == '__main__':
    d1 = {"class": {"l1": {"name": "jack", 'age': {"j": 1}}}, 'l2': {"name": 'laowang', "age": 13}}
    d2 = {"class": {"l1": {"name": "jacks", 'age': {'k': 3}}}, 'l2': {"name": 'laowang', "age": 1, 'gender': 'male'}}


    CompareTwoDict(d1,d2).compare_data

