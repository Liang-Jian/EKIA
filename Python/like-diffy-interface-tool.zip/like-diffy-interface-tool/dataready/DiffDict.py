class DiffDict(object):
    """获取两个dict的差异"""

    def __init__(self, current, last):
        self.current = current
        self.last = last
        self.set_current = set(current)
        self.set_last = set(last)
        self.intersect_keys = self.set_current & self.set_last

    def get_added(self):
        """current - 交集 = 新增的key"""
        added_keys = self.set_current - self.intersect_keys
        return [{'key': key, 'value': self.current.get(key)} for key in added_keys]

    def get_removed(self):
        """last - 交集 = 减去的key"""
        removed_keys = self.set_last - self.intersect_keys
        return [{'key': key, 'value': self.current.get(key)} for key in removed_keys]

    def get_changed(self):
        """用交集中的key去两个dict中找出值不相等的"""
        changed_keys = set(o for o in self.intersect_keys if self.current.get(o) != self.last.get(o))
        return [{
            'key': key,
            'value': '%s -> %s' % (self.last.get(key), self.current.get(key))
        } for key in changed_keys]





if __name__=="__main__":
    dict1 = { "xxx": 0,"code": 0, "message": "SUCCESS", "value": [ { "spaceType":2, "cityId": 0, "showStartTime": "2020-06-13 00:00:00", "showEndTime": "2020-06-30 00:00:00", "title": "亚丽", "pic": "http://picspy.lexue.com/avatar-employee-1592029521432", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=64", "backcolor": "#ffffff", "versionControl": 1, "adId": 999 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-11 00:00:00", "showEndTime": "2020-06-26 00:00:00", "title": "请叫我大哥", "pic": "http://picspy.lexue.com/avatar-employee-1582770255391", "linkMode": 2, "keywords": "", "url": "lexuepeiyou://lectureDetail?classId=101583&schoolId=290", "backcolor": "#00EEFF", "versionControl": 1, "adId": 994 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-19 00:00:00", "showEndTime": "2020-07-01 00:00:00", "title": "方城一中", "pic": "http://picspy.lexue.com/avatar-employee-1592532603842", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=63", "backcolor": "#0D00FF", "versionControl": 1, "adId": 997 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-12 00:00:00", "showEndTime": "2020-07-30 00:00:00", "title": "班级cs", "pic": "http://picspy.lexue.com/avatar-employee-1591945830012", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=20", "backcolor": "#141313", "versionControl": 1, "adId": 992 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-12 00:00:00", "showEndTime": "2020-07-30 00:00:00", "title": "图片cs", "pic": "http://picspy.lexue.com/avatar-employee-1591946207475", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=22", "backcolor": "#190303", "versionControl": 1, "adId": 993 } ] }
    dict2 ={"123": 0, "code": 0, "message": "SUCCESS2", "value": [ { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-13 00:00:00", "showEndTime": "2020-06-30 00:00:00", "title": "亚丽", "pic": "http://picspy.lexue.com/avatar-employee-1592029521432", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=64", "backcolor": "#ffffff", "versionControl": 1, "adId": 999 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-11 00:00:00", "showEndTime": "2020-06-26 00:00:00", "title": "请叫我大哥", "pic": "http://picspy.lexue.com/avatar-employee-1582770255391", "linkMode": 2, "keywords": "", "url": "lexuepeiyou://lectureDetail?classId=101583&schoolId=290", "backcolor": "#00EEFF", "versionControl": 1, "adId": 994 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-19 00:00:00", "showEndTime": "2020-07-01 00:00:00", "title": "方城一中", "pic": "http://picspy.lexue.com/avatar-employee-1592532603842", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=63", "backcolor": "#0D00FF", "versionControl": 1, "adId": 997 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-12 00:00:00", "showEndTime": "2020-07-30 00:00:00", "title": "班级cs", "pic": "http://picspy.lexue.com/avatar-employee-1591945830012", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=20", "backcolor": "#141313", "versionControl": 1, "adId": 992 }, { "spaceType": 1, "cityId": 0, "showStartTime": "2020-06-12 00:00:00", "showEndTime": "2020-07-30 00:00:00", "title": "图片cs", "pic": "http://picspy.lexue.com/avatar-employee-1591946207475", "linkMode": 2, "keywords": "", "url": "http://stest.lexue.com/peiyou/theme?specialId=22", "backcolor": "#190303", "versionControl": 1, "adId": 993 } ] }
    dict3 = {"123": 0, "code": 0, "message": "SUCCESS2", "value": [
        {"spaceType": 1, "cityId": 0, "showStartTime": "2020-06-13 00:00:00", "showEndTime": "2020-06-30 00:00:00",
         "title": "亚丽", "pic": "http://picspy.lexue.com/avatar-employee-1592029521432", "linkMode": 2, "keywords": "",
         "url": "http://stest.lexue.com/peiyou/theme?specialId=64", "backcolor": "#ffffff", "versionControl": 1,
         "adId": 999},
        {"spaceType": 1, "cityId": 0, "showStartTime": "2020-06-11 00:00:00", "showEndTime": "2020-06-26 00:00:00",
         "title": "请叫我大哥", "pic": "http://picspy.lexue.com/avatar-employee-1582770255391", "linkMode": 2,
         "keywords": "", "url": "lexuepeiyou://lectureDetail?classId=101583&schoolId=290", "backcolor": "#00EEFF",
         "versionControl": 1, "adId": 994},
        {"spaceType": 1, "cityId": 0, "showStartTime": "2020-06-19 00:00:00", "showEndTime": "2020-07-01 00:00:00",
         "title": "方城一中", "pic": "http://picspy.lexue.com/avatar-employee-1592532603842", "linkMode": 2, "keywords": "",
         "url": "http://stest.lexue.com/peiyou/theme?specialId=63", "backcolor": "#0D00FF", "versionControl": 1,
         "adId": 997},
        {"spaceType": 1, "cityId": 0, "showStartTime": "2020-06-12 00:00:00", "showEndTime": "2020-07-30 00:00:00",
         "title": "班级cs", "pic": "http://picspy.lexue.com/avatar-employee-1591945830012", "linkMode": 2, "keywords": "",
         "url": "http://stest.lexue.com/peiyou/theme?specialId=20", "backcolor": "#141313", "versionControl": 1,
         "adId": 992},
        {"spaceType": 1, "cityId": 0, "showStartTime": "2020-06-12 00:00:00", "showEndTime": "2020-07-30 00:00:00",
         "title": "图片cs", "pic": "http://picspy.lexue.com/avatar-employee-1591946207475", "linkMode": 2, "keywords": "",
         "url": "http://stest.lexue.com/peiyou/theme?specialId=22", "backcolor": "#190303", "versionControl": 1,
         "adId": 993}]}
    # print(type(dict1))
    result1 = DiffDict(dict1,dict2).get_added()
    result2 = DiffDict(dict1, dict2).get_changed()
    result3 = DiffDict(dict1, dict2).get_removed()
    print(result1)
    print(result2)
    print(result3)