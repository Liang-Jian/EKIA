import logging,os
import logging.handlers

'''
log module copy from android studio Log style 

Logi:info
Logd:dubug
Logw:warn
Loge:error


create by j0ker

'''
parentDirPath = os.getcwd()

def logconfig():

    logger = logging.getLogger("LX")
    logger.setLevel(logging.INFO)                                                                       # set global default log level
    ch = logging.StreamHandler()                                                                        # create Handler object
    ch.setLevel(logging.DEBUG)
    fh = logging.FileHandler(parentDirPath + "./log.txt", encoding="utf8")
    fh.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s %(message)s")            # create formatter object
    console_formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    ch.setFormatter(console_formatter)
    fh.setFormatter(file_formatter)
    logger.addHandler(ch)                                                                               # put Handler object bind logger
    logger.addHandler(fh)
    return logger

log = logconfig()

def Logd(msg):
    log.debug(msg)

def Logi(msg):
    log.info(msg)

def Logw(msg):
    log.warning(msg)

def Loge(msg):
    log.error(msg)

def logger_critical(msg):
    log.critical(msg)


