from jinja2 import  Environment,FileSystemLoader
from sourcefile import signatureUtil


def testjj2():
    env = Environment(loader=FileSystemLoader('../template'))               # template file
    tpl = env.get_template('test.vm')                                       # te
    s = tpl.render(phone='137867867')
    s2 = tpl.render(pageNum='137867867')
    print(s2)


#
# import urllib.parse
# values={}
# values['loginName']='13716697293'
# values['password']='697293'
# url="http://pycmstest.lexue.com/login"
# data=urllib.parse.urlencode(values)
# print(data)



import requests
url="http://test58.bms.lexue.com/system/sysUser/login"
par = {
    "appKey": "201820011141153",
    "token": "123",
    "signature": "61AB9B887044C2745C169371A688611DD08C50DB",
    "tenantId": "test58"
}
body = {
    "loginName": "13716697293",
    "password": "697293"
}


body1 = {  "cityId":"13671388253", "gradeName":"五年级"}
par['signature'] =signatureUtil.Signature().get_signature(body)
print(par)
r = requests.post(url, data=body1,headers=par)
print(r.text)