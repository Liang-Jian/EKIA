# 操作说明
### 操作手册
1，需要先 cd JinDouYunCases 这个目录下后执行后两条命令  
2，先执行py.test JinDouYun.py --alluredir ..\reports 生成结果文件  
3，之后执行start /b allure serve ..\reports

### 类库安装
使用国内源安装pip  
`python -m pip install -r requirement -i https://pypi.tuna.tsinghua.edu.cn/simple`