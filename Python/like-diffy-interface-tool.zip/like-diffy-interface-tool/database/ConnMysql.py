# -*-coding:utf-8-*-
from mysql import connector
import os
from ruamel import yaml

'''

author: chen
time  : 9/13


'''
class ConnMysql:


    def __init__(self):
        file = open(os.path.abspath('..') + r"\configure\database.yml", "r", encoding="utf8")
        config = yaml.load(file.read(), Loader=yaml.Loader)
        conf = config["mysql"]
        self.host = conf["host"]
        self.port = conf["port"]
        self.name = conf["name"]
        self.user = conf["user"]
        self.password = conf["password"]
        self.charset = "utf8"
        self.conn = connector.connect(host=self.host, user=self.user, password=self.password, db=self.name,
                                       port=self.port, charset=self.charset)


    def fetch_all(self, sql):
        flag = False
        try:
            self.cursor = self.conn.cursor()
            self.cursor.execute(sql)
            select_data = self.cursor.fetchall()
            flag = True
            print (select_data)
        finally:
            return flag
    def search_db(self,sql):
        self.cursor = self.conn.cursor()
        self.cursor.execute(sql)
        select_data = self.cursor.fetchall()
        return select_data

    def insert(self, sql, value):
        flag = False
        try:
            self.conn.cursor().execute(sql, value)
            # print(self._cursor.lastrowid)
            self.conn.commit()
            flag = True
        finally:
            return flag

    def update(self, sql, value):
        flag = False
        try:
            self.conn.cursor().execute(sql, value)
            self.conn.commit()
            flag = True
        finally:
            return flag

    def close(self):
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
if __name__ == '__main__':
    # sql="select nick_name from py_user where login_mobile='13423250001'"
    sql="select nick_name from py_user"
    result=ConnMysql().search_db(sql)
    print(result)