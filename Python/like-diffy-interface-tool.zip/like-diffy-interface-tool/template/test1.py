from jinja2 import Template,PackageLoader,Environment
import sourcefile.tools as tooltest
import json


def main():
    env=Environment(loader=PackageLoader("",""))

    tpl = Template('{"name":"{{name}}", "pageSize":"10", "sourceType":"1"}')
    print (tpl.render(name='world'))
    # print(type(tpl))
    print(tooltest.phoneNum("phone-010"))
def main1():
    tpl = Template('{"phone":"{{phone}}", "pageSize":"10", "sourceType":"1"}')
    # print(tpl.render(phone=tooltest.phoneNum("phone-010")))
    print(tpl.render(phone=tooltest.randomStr(4)))
    # print(type(tpl))


def main1():
    tpl = Template(r'D:\python\like-diffy-interface-tool\template\test.vm')
    # print(tpl.render(phone=tooltest.phoneNum("phone-010")))
    # print(tpl.render(name=tooltest.randomStr(3)))
    # sss = json.loads(tpl.render(name=))
    print(tpl.render(name=tooltest.randomStr(3)))
if __name__=='__main__':
    main1()