# -*-coding:utf-8-*-
import os

from openpyxl import load_workbook


class ReadWriteExcel:

    def __init__(self, path):
        self.workbook = None
        if os.path.exists(path):
            self.path = path
            self.workbook = load_workbook(self.path)
        else:
            print("%s 文件不存在" % path)
            exit(0)

    def get_sheets_name(self):
        if self.workbook:
            return self.workbook.sheetnames
        return None

    def get_sheet_name_by_index(self, index):
        if self.workbook:
            sheets = self.workbook.sheetnames
            if 0 <= index < len(sheets):
                return sheets[index]
        return None

    def get_cell_row(self, sheet):
        if self.workbook:
            sh = self.workbook[sheet]
            if sh:
                return sh.max_row
        return None

    def get_cell_col(self, sheet):
        if self.workbook:
            sh = self.workbook[sheet]
            if sh:
                return sh.max_column
        return None

    def create_sheet(self, name, index=0):
        res = False
        if self.workbook:
            self.workbook.create_sheet(name, index)
            res = True
        return res

    def get_cell_value(self, sheet, row, col):
        value = None
        if self.workbook:
            value = self.workbook[sheet].cell(row=row, column=col).value
        return value

    def set_cell_value(self, sheet, row, col, value):
        res = False
        if self.workbook:
            self.workbook[sheet].cell(row=row, column=col).value = value
            res = True
        return res

    def save(self, path=""):
        if path != "":
            self.path = path
        if self.workbook:
            self.workbook.save(self.path)

    def close(self):
        if self.workbook:
            self.workbook.close()
