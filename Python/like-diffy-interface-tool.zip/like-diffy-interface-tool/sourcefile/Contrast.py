# -*-coding:utf-8-*-


class DictCmp:
    """
    判断字典之间的包含关系

    """

    def compare_dict(self, src_data, dst_data):
        if isinstance(dst_data, dict):
            for key in dst_data:
                if key not in src_data:
                    return False
            for key in dst_data:
                dst_val = dst_data.get(key)
                src_val = src_data.get(key)
                flag = self.compare_dict(src_val, dst_val)
                if flag is False:
                    return False
            return True
        if isinstance(dst_data, list):
            if len(dst_data) > len(src_data):
                return False
            for dst_list in dst_data:
                res = False
                for src_list in src_data:
                    res = self.compare_dict(src_list, dst_list)
                    if res:
                        break
                if res is False:
                    return False
            return True
        else:
            if str(dst_data) != str(src_data):
                return False
            return True
