# -*- encoding:utf-8 -*-
import json
from datetime import datetime
import allure
from sourcefile.Contrast import DictCmp
from sourcefile.HttpMethods import HttpMethods
from sourcefile.signatureUtil import Signature
from dataready.DiffDict import  DiffDict
import dataready.global_var as gl
gl.init()
def get_list(length):
    new_list = []
    if length > 0:
        for i in range(length):
            new_list.append(str(i))
    return new_list


def method_case(url,url2, header, req, method, expect, remark,relation):
    with allure.step("用例描述：  {0}".format(remark)):
        pass

    with allure.step("测试时间：  {0}".format(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))):
        pass

    with allure.step("测试步骤1、获取入参"):

        # if "_value(" in expect:
        #     arg1=expect.split(",")
        #     req= req.replace(arg1[2], gl.get(arg1[0]))
        #     req2 = req.replace(arg1[2], gl.get(arg1[1]))
        #     dic_data = json.loads(req)
        #     login_sginature = Signature().get_signature(dic_data)
        #     str_headers = header.replace("signature_value", login_sginature)
        #     dic_data2 = json.loads(req2)
        #     login_sginature2 = Signature().get_signature(dic_data2)
        #     str_headers2 = header.replace("signature_value", login_sginature2)
        #
        # else:


            if relation:
                arg1 = relation.split(",")
                if "YES" not in relation:
                    dic_data = json.loads(req)
                    login_sginature = Signature().get_signature(dic_data)
                    str_headers = header.replace("signature_value", login_sginature)
                    str_headers2 = str_headers
                    print(str_headers2)
                    allure.attach(str(str_headers), "获取signature后header")
                    result = HttpMethods().get_result(url, method, json.loads(str_headers), str(req))
                    result2 = HttpMethods().get_result(url2, method, json.loads(str_headers2), str(req))
                    if len(arg1) == 1:
                        str3 = result.json()[arg1[0]]
                        str4 = arg1[0]
                        str5 = result2.json()[arg1[0]]
                        str6 = arg1[0]+"2"
                    elif len(arg1) == 2:
                        str3 = result.json()[arg1[0]][arg1[1]]
                        str4 = arg1[1]
                        str5 = result2.json()[arg1[0]][arg1[1]]
                        str6 = arg1[1]+"2"
                    elif len(arg1) == 3:
                        str3 = result.json()[arg1[0]][arg1[1]][arg1[2]]
                        str4 = arg1[2]
                        str5 = result2.json()[arg1[0]][arg1[1]][arg1[2]]
                        str6 = arg1[2]+"2"
                    elif len(arg1) == 4:
                        str3 = result.json()[arg1[0]][arg1[1]][int(arg1[2])][arg1[3]]
                        str4 = arg1[3]
                        str5 = result2.json()[arg1[0]][arg1[1]][int(arg1[2])][arg1[3]]
                        str6 = arg1[3]+"2"
                    gl.set_value(str4, str3)
                    gl.set_value(str6, str5)
                    test1=gl
                    test2=gl
                else:
                    str7 = gl.get_value(arg1[1])
                    str8 = gl.get_value(arg1[1]+"2")
                    req2=req
                    req = req.replace("variable_value", str7)
                    req2 = req2.replace("variable_value", str8)
                    dic_data = json.loads(req)
                    login_sginature = Signature().get_signature(dic_data)
                    str_headers = header.replace("signature_value", login_sginature)
                    dic_data2 = json.loads(req2)
                    login_sginature2 = Signature().get_signature(dic_data2)
                    str_headers2 = header.replace("signature_value", login_sginature2)
                    # str_headers2 = str_headers
                    allure.attach(str(req), "获取关联值后的请求")
                    allure.attach(str(str_headers), "获取signature后header")
                    result = HttpMethods().get_result(url, method, json.loads(str_headers), str(req))
                    result2 = HttpMethods().get_result(url2, method, json.loads(str_headers2), str(req2))

            else:
                dic_data = json.loads(req)
                login_sginature = Signature().get_signature(dic_data)
                str_headers = header.replace("signature_value", login_sginature)
                str_headers2 = str_headers
                allure.attach(str(str_headers), "获取signature后header")
                result = HttpMethods().get_result(url, method, json.loads(str_headers), str(req))
                result2 = HttpMethods().get_result(url2, method, json.loads(str_headers2), str(req))

    with allure.step("测试步骤2、获取响应结果"):
        # allure.attach("url", ":  " + str(url))
        # allure.attach(str(url),"url")
        # allure.attach("method", ":  " + str(method))
        allure.attach(str(json.dumps(result.json(), indent=4, ensure_ascii=False)),"新环境响应结果")
        allure.attach(str(json.dumps(result2.json(), indent=4, ensure_ascii=False)),"老环境响应结果")

    res1 = DiffDict(json.loads(result.text), json.loads(result2.text)).get_added()


    # res2 = DiffDict(result, result2).get_changed()
    res2 = DiffDict(json.loads(result.text), json.loads(result2.text)).get_changed()

    res3 = DiffDict(json.loads(result.text), json.loads(result2.text)).get_removed()
    res=False

    res4 = DictCmp().compare_dict(result.json(), json.loads(expect))
    # print("类型",type(res2))
    # if res1 == True and res1 is None and res4 is None:
    if res4 and len(res1)==False and len(res2)==False and len(res3)==False:
       res=True

    with allure.step("测试步骤3、断言校验结果: {0}".format("PASS" if res4 else "FAILED")):
        allure.attach(expect,"新环境断言设置")

    with allure.step("测试步骤4、测试环境和线上环境结果差异展示"):
        allure.attach(str(res1),"增加")
        allure.attach(str(res2),"改变")
        allure.attach(str(res3),"缺少")


        assert res
